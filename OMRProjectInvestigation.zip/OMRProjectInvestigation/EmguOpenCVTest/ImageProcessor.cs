﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EmguOpenCVTest
{
    public class ImageProcessor
    {
        private static Dictionary<string, string> _colors = new Dictionary<string, string>();

        public static List<Note> Notes { get; set; } = new List<Note>();
        public static List<GroupedNote> GroupedNotes { get; set; } = new List<GroupedNote>();
        public static List<GroupedNote> OrderedGroupedNotes { get; set; } = new List<GroupedNote>();
        public static List<double> StaffLines = new List<double>();

        public static List<double> DetectLines(Bitmap bitmap)
        {
            int x = 0;
            int firstNonWhitePixelY = 0;
            int lineThickness = 3;
            int depth = 0;

            List<double> linesYPixel = new List<double>();
            for (int y = 0; y < bitmap.Height; y++)
            {
                if (bitmap.GetPixel(x, y).Name != "ffffffff")
                {
                    firstNonWhitePixelY = y;
                    depth += 1;
                }

                if(firstNonWhitePixelY !=0 && depth == lineThickness)
                {
                    linesYPixel.Add(firstNonWhitePixelY);
                    firstNonWhitePixelY = 0;
                    depth = 0;
                }
            }

            //clean lines and remove possible duplicates to endup with a set of 5-line segments

            //get average distance between each line within a 5-line segment
            int i = 1;
            //double globalAvgDistance = 0;
            double sgmAvgDistance = 0;
            double prevSgmAvgDistance = 0;
            int segmentStartIndex = 0;

            while (i < linesYPixel.Count)
            {
                sgmAvgDistance = (double)(sgmAvgDistance + linesYPixel[i] - linesYPixel[i-1]) / (sgmAvgDistance == 0? 1 : 2); //8, 7, 8, 7, 57

                if((prevSgmAvgDistance != 0 && sgmAvgDistance / prevSgmAvgDistance > 2) || IsLastItem(i, linesYPixel))
                {
                    //5-line segment possibly detected
                    var segment = linesYPixel.GetRange(segmentStartIndex, !IsLastItem(i, linesYPixel) ? i - segmentStartIndex : i + 1 - segmentStartIndex);
                    StaffLines.AddRange(RemoveDuplicateLines(segment, prevSgmAvgDistance));
                    sgmAvgDistance = 0;
                    prevSgmAvgDistance = 0;
                    segmentStartIndex = i;
                }
                else
                {
                    prevSgmAvgDistance = sgmAvgDistance;
                }
               
                //if(prevSgmAvgDistance != 0)
                //{
                //    globalAvgDistance = GetGlobalAvgDistance(i, globalAvgDistance, prevSgmAvgDistance);                  
                //}
                   

                i += 1;
            }

            return StaffLines;
        }

        private static bool IsLastItem(int itemIndex, List<double> items)
        {
            return itemIndex == items.Count - 1;
        }

        //private static double GetGlobalAvgDistance(int itemIndex, double globalAvgDistance, double newAverage)
        //{
        //    if (itemIndex == 1)
        //    {
        //        return newAverage;
        //    }
        //    else
        //    {
        //       return (globalAvgDistance + newAverage) / 2;
        //    }
        //}


        public static List<double> RemoveDuplicateLines(List<double> segment, double avgDistance)
        {
            if (segment.Count == 5) return segment;

            var cleanLines = new List<double>();
            cleanLines.Add(segment[0]);
            int i = 1;
           
            while (i < segment.Count)
            {
                if((segment[i] - segment[i-1]) / avgDistance > 0.5)
                {
                    cleanLines.Add(segment[i]);
                }
                else
                {
                    //calculate the average between the previous and current item and replace the previous item with the average
                    cleanLines[i - 1] = (cleanLines[i - 1] + segment[i]) / 2;
                }

                i += 1;
            }

            return cleanLines;
        }

        public static List<Note> FindGroupedNotes(Note note, int radius)
        {
            List<Note> groupedNotes = new List<Note>();

            //TO DO : found notes should be removed from the main property Notes

            groupedNotes.AddRange(Notes.Where(n => (Math.Abs(n.X - note.X) <= radius) && (Math.Abs(n.Y - note.Y) <= radius)).ToList());
            return groupedNotes;
        }

        public static void DrawGroupedNotes(Bitmap bitmap, List<Note> groupedNotes, int radius)
        {
            int firstLeftNoteX = groupedNotes.Min(n => n.X);
            int lastRightNoteX = groupedNotes.Max(n => n.X);

            int topNoteY = groupedNotes.Min(n => n.Y);
            int bottomNoteY = groupedNotes.Max(n => n.Y);

            int x = firstLeftNoteX;
            int y = topNoteY;
            int width = lastRightNoteX - firstLeftNoteX + radius;
            int height = bottomNoteY - topNoteY + radius;

            if(GroupedNotes.Where(gn => gn.X == x && gn.Y==y && gn.Width == width && gn.Height == height).Count() == 0)
            {
                GroupedNotes.Add(new GroupedNote(x, y, width, height, GetNoteSegment(y)));
            }
            
            using (Graphics g = Graphics.FromImage(bitmap))
            {
                g.DrawRectangle(new Pen(Color.Blue), x, y, width, height);
            }
        }

        private static int GetNoteSegment(int noteY)
        {
            int staffLineIndex = StaffLines.FindIndex(y => y >= noteY);

            return staffLineIndex / 5;
        }

        public static void ScanImageColors(Bitmap bitmap)
        {
            for (int x = 0; x < bitmap.Width; x++)
            {
                for (int y = 0; y < bitmap.Height; y++)
                {
                    var key = $"{x}:{y}";
                    _colors.Add(key, bitmap.GetPixel(x,y).Name);
                }
            }
        }

        public static void HighlightColor(Bitmap bitmap, string color)
        {
            for (int x = 0; x < bitmap.Width; x++)
            {
                for (int y = 0; y < bitmap.Height; y++)
                {
                    var key = $"{x}:{y}";
                    if (_colors[key] == $"ff{color}")
                    {                      
                        bitmap.SetPixel(x, y, Color.White);
                    }
                }
            }
        }

        public static double GetDarkBackgroundPercent(int x, int y, int width, int height, int bitmapWidth, int bitmapHeight)
        {
            double percent = 0;
            double blackPixelCount = 0;
            int outsidePixelCount = 0;

            for (int w = 0; w <= width; w++)
            {
                for (int h = 0; h <= height; h++)
                {
                    if (x + w < bitmapWidth && y + h < bitmapHeight)
                    {
                        //var color = _bitmap.GetPixel(x + w, y + h);
                        var key = $"{x + w}:{y + h}";
                        //if (listbox != null)  listbox.Items.Add(_colors[key]);
                        if (_colors[key] == "ff000000")
                        {
                            blackPixelCount += 1;
                        }
                    }
                    else
                    {
                        outsidePixelCount += 1;
                    }
                }
            }

            int surface = (width * height) - outsidePixelCount;
            percent = blackPixelCount / surface;
            return percent;
        }

        public static string[,] GetPixelMatrix(int x, int y, int width, int height, Bitmap bitmap)
        {
            string[,] matrix = new string[width, height];

            for (int w = 0; w < width; w++)
            {
                for (int h = 0; h < height; h++)
                {
                    if (x + w < bitmap.Width && y + h < bitmap.Height)
                    {
                        matrix[w, h] = bitmap.GetPixel(x + w, y + h).Name;
                    }
                    else
                    {
                        matrix[w, h] = "ffffffff";
                    }
                }
            }

            return matrix;
        }
    }
}
