﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmguOpenCVTest
{
    public class GroupedNote
    {
        public int X { get; set; }
        public int Y { get; set; }
        public int Width { get; set; }
        public int Height { get; set; }
        public int Segment { get; set; }
        public string Name { get; set; }
        public int Frequency { get; set; }
        public int TimeLength { get; set; }

        public GroupedNote(int x, int y, int width, int height, int segment)
        {
            X = x;
            Y = y;
            Width = width;
            Height = height;
            Segment = segment;
        }
    }
}
