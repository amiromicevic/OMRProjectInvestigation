﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmguOpenCVTest
{
    public class NoteLevel
    {
        public enum Position
        {
            NotApplicable,
            AboveSegment,
            BelowSegment,
        }

        public int OnLineNo { get; set; }
        public List<int> BetweenLinesNo { get; set; }
        public Position AboveOrBelowSegmentPosition { get; set; }
        public int PositionIndex { get; set; }
        public string Name { get; set; }
        public string Frequency { get; set; }

        public NoteLevel(int onLineNo, string name)
        {
            OnLineNo = onLineNo;
            AboveOrBelowSegmentPosition = Position.NotApplicable;
            Name = name;
        }

        public NoteLevel(int betweenTopLineNo, int betweenBottomLineNo, string name)
        {
            BetweenLinesNo = new List<int>() { betweenTopLineNo, betweenBottomLineNo };
            AboveOrBelowSegmentPosition = Position.NotApplicable;
            Name = name;
        }

        public NoteLevel(Position position, int positionIndex, string name)
        {
            AboveOrBelowSegmentPosition = position;
            PositionIndex = positionIndex;
            Name = name;
        }
    }
}
