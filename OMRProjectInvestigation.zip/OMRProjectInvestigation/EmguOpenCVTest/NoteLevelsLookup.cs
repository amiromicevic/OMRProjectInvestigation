﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmguOpenCVTest
{
    public class NoteLevelsLookup
    {
        private static List<NoteLevel> _notes = new List<NoteLevel>();

        public static List<NoteLevel> Notes
        {
            get
            {
                if (_notes.Count == 0) PopulateNotes();
                return _notes;
            }
        }

        private static void PopulateNotes()
        {
            //above top line G3
            //top line F2
            //first space E2
            //second line D2
            //second space C2
            //third line B2
            //third space A2
            //fourth line G2
            //fourth space F1
            //fifth line E1
            //first below fifth line D2

            _notes.Add(new NoteLevel(NoteLevel.Position.AboveSegment, 0, "G3"));

            _notes.Add(new NoteLevel(0, "F2"));
            _notes.Add(new NoteLevel(0,1, "E2"));

            _notes.Add(new NoteLevel(1, "D2"));
            _notes.Add(new NoteLevel(1, 2, "C2"));

            _notes.Add(new NoteLevel(2, "B2"));
            _notes.Add(new NoteLevel(2, 3, "A2"));

            _notes.Add(new NoteLevel(3, "G2"));
            _notes.Add(new NoteLevel(3, 4, "F1"));

            _notes.Add(new NoteLevel(4, "E1"));

            _notes.Add(new NoteLevel(NoteLevel.Position.BelowSegment, 0, "D1"));
        }

        public static string GetNoteNameAboveLineAt(int positionIndex)
        {
            return Notes.Where(x => x.AboveOrBelowSegmentPosition == NoteLevel.Position.AboveSegment && x.PositionIndex == positionIndex).First().Name;
        }

        public static string GetNoteNameBelowLineAt(int positionIndex)
        {
            return Notes.Where(x => x.AboveOrBelowSegmentPosition == NoteLevel.Position.BelowSegment && x.PositionIndex == positionIndex).First().Name;
        }

        public static string GetNoteNameOnStaffLine(int lineNo)
        {
            return Notes.Where(x => x.OnLineNo == lineNo && x.AboveOrBelowSegmentPosition == NoteLevel.Position.NotApplicable && x.BetweenLinesNo == null).First().Name;
        }

        public static string GetNoteNameBetweenStaffLines(int topLineNo, int bottomLineNo)
        {
            return Notes.Where(x => x.BetweenLinesNo != null && x.BetweenLinesNo[0] == topLineNo && x.BetweenLinesNo[1] == bottomLineNo).First().Name;
        }
    }
}
