﻿namespace EmguOpenCVTest
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.originalImageBox = new Emgu.CV.UI.ImageBox();
            this.triangleRectangleImageBox = new Emgu.CV.UI.ImageBox();
            this.circleImageBox = new Emgu.CV.UI.ImageBox();
            this.lineImageBox = new Emgu.CV.UI.ImageBox();
            this.button3 = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.lblPos = new System.Windows.Forms.Label();
            this.lblColor = new System.Windows.Forms.Label();
            this.lblPercent = new System.Windows.Forms.Label();
            this.button4 = new System.Windows.Forms.Button();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.lblRow = new System.Windows.Forms.Label();
            this.lblColumn = new System.Windows.Forms.Label();
            this.button5 = new System.Windows.Forms.Button();
            this.txtDetectColor = new System.Windows.Forms.TextBox();
            this.button6 = new System.Windows.Forms.Button();
            this.btnDetectNoteNames = new System.Windows.Forms.Button();
            this.pbNote = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.originalImageBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.triangleRectangleImageBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.circleImageBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lineImageBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbNote)).BeginInit();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(15, 12);
            this.button1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(169, 34);
            this.button1.TabIndex = 0;
            this.button1.Text = "Emgu OpenCV Sample";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(189, 12);
            this.button2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(140, 34);
            this.button2.TabIndex = 1;
            this.button2.Text = "Shape detection";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // originalImageBox
            // 
            this.originalImageBox.Location = new System.Drawing.Point(28, 94);
            this.originalImageBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.originalImageBox.Name = "originalImageBox";
            this.originalImageBox.Size = new System.Drawing.Size(549, 400);
            this.originalImageBox.TabIndex = 2;
            this.originalImageBox.TabStop = false;
            // 
            // triangleRectangleImageBox
            // 
            this.triangleRectangleImageBox.Location = new System.Drawing.Point(603, 94);
            this.triangleRectangleImageBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.triangleRectangleImageBox.Name = "triangleRectangleImageBox";
            this.triangleRectangleImageBox.Size = new System.Drawing.Size(549, 400);
            this.triangleRectangleImageBox.TabIndex = 2;
            this.triangleRectangleImageBox.TabStop = false;
            this.triangleRectangleImageBox.Click += new System.EventHandler(this.triangleRectangleImageBox_Click);
            // 
            // circleImageBox
            // 
            this.circleImageBox.Location = new System.Drawing.Point(28, 517);
            this.circleImageBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.circleImageBox.Name = "circleImageBox";
            this.circleImageBox.Size = new System.Drawing.Size(549, 400);
            this.circleImageBox.TabIndex = 2;
            this.circleImageBox.TabStop = false;
            // 
            // lineImageBox
            // 
            this.lineImageBox.Location = new System.Drawing.Point(603, 517);
            this.lineImageBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.lineImageBox.Name = "lineImageBox";
            this.lineImageBox.Size = new System.Drawing.Size(549, 400);
            this.lineImageBox.TabIndex = 2;
            this.lineImageBox.TabStop = false;
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(335, 12);
            this.button3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(115, 34);
            this.button3.TabIndex = 3;
            this.button3.Text = "Load image";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(28, 94);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(1147, 506);
            this.pictureBox1.TabIndex = 4;
            this.pictureBox1.TabStop = false;
            // 
            // lblPos
            // 
            this.lblPos.AutoSize = true;
            this.lblPos.Location = new System.Drawing.Point(952, 11);
            this.lblPos.Name = "lblPos";
            this.lblPos.Size = new System.Drawing.Size(46, 17);
            this.lblPos.TabIndex = 5;
            this.lblPos.Text = "label1";
            // 
            // lblColor
            // 
            this.lblColor.AutoSize = true;
            this.lblColor.Location = new System.Drawing.Point(955, 41);
            this.lblColor.Name = "lblColor";
            this.lblColor.Size = new System.Drawing.Size(46, 17);
            this.lblColor.TabIndex = 6;
            this.lblColor.Text = "label2";
            // 
            // lblPercent
            // 
            this.lblPercent.AutoSize = true;
            this.lblPercent.Location = new System.Drawing.Point(1204, 11);
            this.lblPercent.Name = "lblPercent";
            this.lblPercent.Size = new System.Drawing.Size(46, 17);
            this.lblPercent.TabIndex = 7;
            this.lblPercent.Text = "label1";
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(455, 12);
            this.button4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(124, 34);
            this.button4.TabIndex = 8;
            this.button4.Text = "Sliding window";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.ItemHeight = 16;
            this.listBox1.Location = new System.Drawing.Point(1267, 12);
            this.listBox1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(148, 612);
            this.listBox1.TabIndex = 9;
            this.listBox1.SelectedIndexChanged += new System.EventHandler(this.listBox1_SelectedIndexChanged);
            // 
            // lblRow
            // 
            this.lblRow.AutoSize = true;
            this.lblRow.Location = new System.Drawing.Point(1083, 57);
            this.lblRow.Name = "lblRow";
            this.lblRow.Size = new System.Drawing.Size(35, 17);
            this.lblRow.TabIndex = 10;
            this.lblRow.Text = "Row";
            // 
            // lblColumn
            // 
            this.lblColumn.AutoSize = true;
            this.lblColumn.Location = new System.Drawing.Point(1159, 57);
            this.lblColumn.Name = "lblColumn";
            this.lblColumn.Size = new System.Drawing.Size(55, 17);
            this.lblColumn.TabIndex = 11;
            this.lblColumn.Text = "Column";
            this.lblColumn.Click += new System.EventHandler(this.label1_Click);
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(585, 12);
            this.button5.Margin = new System.Windows.Forms.Padding(4);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(100, 34);
            this.button5.TabIndex = 12;
            this.button5.Text = "Detect lines";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // txtDetectColor
            // 
            this.txtDetectColor.Location = new System.Drawing.Point(51, 58);
            this.txtDetectColor.Margin = new System.Windows.Forms.Padding(4);
            this.txtDetectColor.Name = "txtDetectColor";
            this.txtDetectColor.Size = new System.Drawing.Size(132, 22);
            this.txtDetectColor.TabIndex = 13;
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(189, 53);
            this.button6.Margin = new System.Windows.Forms.Padding(4);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(140, 34);
            this.button6.TabIndex = 14;
            this.button6.Text = "Show on image";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // btnDetectNoteNames
            // 
            this.btnDetectNoteNames.Location = new System.Drawing.Point(695, 12);
            this.btnDetectNoteNames.Margin = new System.Windows.Forms.Padding(4);
            this.btnDetectNoteNames.Name = "btnDetectNoteNames";
            this.btnDetectNoteNames.Size = new System.Drawing.Size(143, 34);
            this.btnDetectNoteNames.TabIndex = 15;
            this.btnDetectNoteNames.Text = "Detect note names";
            this.btnDetectNoteNames.UseVisualStyleBackColor = true;
            this.btnDetectNoteNames.Click += new System.EventHandler(this.button7_Click);
            // 
            // pbNote
            // 
            this.pbNote.Location = new System.Drawing.Point(114, 621);
            this.pbNote.Name = "pbNote";
            this.pbNote.Size = new System.Drawing.Size(239, 252);
            this.pbNote.TabIndex = 16;
            this.pbNote.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1427, 943);
            this.Controls.Add(this.pbNote);
            this.Controls.Add(this.btnDetectNoteNames);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.txtDetectColor);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.lblColumn);
            this.Controls.Add(this.lblRow);
            this.Controls.Add(this.listBox1);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.lblPercent);
            this.Controls.Add(this.lblColor);
            this.Controls.Add(this.lblPos);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.lineImageBox);
            this.Controls.Add(this.circleImageBox);
            this.Controls.Add(this.triangleRectangleImageBox);
            this.Controls.Add(this.originalImageBox);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.originalImageBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.triangleRectangleImageBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.circleImageBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lineImageBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbNote)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private Emgu.CV.UI.ImageBox originalImageBox;
        private Emgu.CV.UI.ImageBox triangleRectangleImageBox;
        private Emgu.CV.UI.ImageBox circleImageBox;
        private Emgu.CV.UI.ImageBox lineImageBox;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label lblPos;
        private System.Windows.Forms.Label lblColor;
        private System.Windows.Forms.Label lblPercent;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.Label lblRow;
        private System.Windows.Forms.Label lblColumn;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.TextBox txtDetectColor;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button btnDetectNoteNames;
        private System.Windows.Forms.PictureBox pbNote;
    }
}

