﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Emgu.CV;
using Emgu.CV.CvEnum;
using Emgu.CV.Structure;
using Emgu.CV.UI;
using System.Diagnostics;
using Emgu.CV.Util;
using System.Globalization;
using System.Threading;
using NAudio.Midi;

namespace EmguOpenCVTest
{
    public partial class Form1 : Form
    {
        private Bitmap _bitmap;
        private string _bitmapFile = @"C: \Users\Amir\source\repos\EmguOpenCVTest\EmguOpenCVTest\notation1.png";
        int _radius = 10;

        int _width = 10;
        int _height = 10;
        
        int _xDensity = 2; 
        int _yDensity = 2;

        int _lastXMouseMove = 0;
        int _lastYMouseMove = 0;

        public Form1()
        {
            InitializeComponent();
            //button1_Click(null,null);
            pictureBox1.MouseMove += PictureBox1_MouseMove;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Task.Run(() =>
            {
                ViewerForm frmViewer = new ViewerForm();
            });
          
        }

        private void button2_Click(object sender, EventArgs e)
        {
            StringBuilder msgBuilder = new StringBuilder("Performance: ");

            //Load the image from file and resize it for display
            Image<Bgr, Byte> img =
               new Image<Bgr, byte>(@"C:\Users\Amir\source\repos\EmguOpenCVTest\EmguOpenCVTest\Opencvpic3sample.png")
               .Resize(400, 400, Emgu.CV.CvEnum.Inter.Linear, true);

            //Convert the image to grayscale and filter out the noise
            UMat uimage = new UMat();
            CvInvoke.CvtColor(img, uimage, ColorConversion.Bgr2Gray);

            //use image pyr to remove noise
            UMat pyrDown = new UMat();
            CvInvoke.PyrDown(uimage, pyrDown);
            CvInvoke.PyrUp(pyrDown, uimage);

            //Image<Gray, Byte> gray = img.Convert<Gray, Byte>().PyrDown().PyrUp();

            #region circle detection
            Stopwatch watch = Stopwatch.StartNew();
            double cannyThreshold = 180.0;
            double circleAccumulatorThreshold = 120;
            CircleF[] circles = CvInvoke.HoughCircles(uimage, HoughType.Gradient, 2.0, 20.0, cannyThreshold, circleAccumulatorThreshold, 5);

            watch.Stop();
            msgBuilder.Append(String.Format("Hough circles - {0} ms; ", watch.ElapsedMilliseconds));
            #endregion

            #region Canny and edge detection
            watch.Reset(); watch.Start();
        double cannyThresholdLinking = 120.0;
            UMat cannyEdges = new UMat();
            CvInvoke.Canny(uimage, cannyEdges, cannyThreshold, cannyThresholdLinking);

            //LineSegment2D[] lines = CvInvoke.HoughLinesP(
            //   cannyEdges,
            //   1, //Distance resolution in pixel-related units
            //   Math.PI / 45.0, //Angle resolution measured in radians.
            //   20, //threshold
            //   30, //min Line width
            //   10); //gap between lines

            LineSegment2D[] lines = CvInvoke.HoughLinesP(
               cannyEdges,
               1, Math.PI / 180, 50, 50, 10); //gap between lines


            watch.Stop();
            msgBuilder.Append(String.Format("Canny & Hough lines - {0} ms; ", watch.ElapsedMilliseconds));
            #endregion

            #region Find triangles and rectangles
            watch.Reset(); watch.Start();
            List<Triangle2DF> triangleList = new List<Triangle2DF>();
            List<RotatedRect> boxList = new List<RotatedRect>(); //a box is a rotated rectangle

            using (VectorOfVectorOfPoint contours = new VectorOfVectorOfPoint())
            {
                CvInvoke.FindContours(cannyEdges, contours, null, RetrType.List, ChainApproxMethod.ChainApproxSimple);
                int count = contours.Size;
                for (int i = 0; i < count; i++)
                {
                    using (VectorOfPoint contour = contours[i])
                    using (VectorOfPoint approxContour = new VectorOfPoint())
                    {
                        CvInvoke.ApproxPolyDP(contour, approxContour, CvInvoke.ArcLength(contour, true) * 0.05, true);
                        if (CvInvoke.ContourArea(approxContour, false) > 250) //only consider contours with area greater than 250
                        {
                            if (approxContour.Size == 3) //The contour has 3 vertices, it is a triangle
                            {
                                Point[] pts = approxContour.ToArray();
                                triangleList.Add(new Triangle2DF(
                                   pts[0],
                                   pts[1],
                                   pts[2]
                                   ));
                            }
                            else if (approxContour.Size == 4) //The contour has 4 vertices.
                            {
                                #region determine if all the angles in the contour are within [80, 100] degree
                                bool isRectangle = true;
                                Point[] pts = approxContour.ToArray();
                                LineSegment2D[] edges = PointCollection.PolyLine(pts, true);

                                for (int j = 0; j < edges.Length; j++)
                                {
                                    double angle = Math.Abs(
                                       edges[(j + 1) % edges.Length].GetExteriorAngleDegree(edges[j]));
                                    if (angle < 80 || angle > 100)
                                    {
                                        isRectangle = false;
                                        break;
                                    }
                                }
                                #endregion

                                if (isRectangle) boxList.Add(CvInvoke.MinAreaRect(approxContour));
                            }
                        }
                    }
                }
            }

            watch.Stop();
            msgBuilder.Append(String.Format("Triangles & Rectangles - {0} ms; ", watch.ElapsedMilliseconds));
            #endregion

            originalImageBox.Image = img;
            this.Text = msgBuilder.ToString();

            #region draw triangles and rectangles
            Image<Bgr, Byte> triangleRectangleImage = img.CopyBlank();
            foreach (Triangle2DF triangle in triangleList)
                triangleRectangleImage.Draw(triangle, new Bgr(Color.DarkBlue), 2);
            foreach (RotatedRect box in boxList)
                triangleRectangleImage.Draw(box, new Bgr(Color.DarkOrange), 2);
            triangleRectangleImageBox.Image = triangleRectangleImage;
            #endregion

            #region draw circles
            Image<Bgr, Byte> circleImage = img.CopyBlank();
            foreach (CircleF circle in circles)
                circleImage.Draw(circle, new Bgr(Color.Brown), 2);
            circleImageBox.Image = circleImage;
            #endregion

            #region draw lines
            Image<Bgr, Byte> lineImage = img.CopyBlank();
            foreach (LineSegment2D line in lines)
                lineImage.Draw(line, new Bgr(Color.Green), 2);
            lineImageBox.Image = lineImage;
            #endregion
        }

        private void triangleRectangleImageBox_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            _bitmap = new Bitmap(_bitmapFile);
            pictureBox1.Image = _bitmap;
            pictureBox1.Width = _bitmap.Width;
            pictureBox1.Height = _bitmap.Height;

            this.Text = $"{_bitmap.Width.ToString()}:{ _bitmap.Height.ToString()}";

            ImageProcessor.ScanImageColors(_bitmap);

            //for (int w = 0; w < _bitmap.Width; w++)
            //{
            //    for (int h = 0; h < _bitmap.Height; h++)
            //    {
            //        var key = $"{w}{h}";
            //        if (!_colors.ContainsKey(key)) _colors.Add(key,_bitmap.GetPixel(w,h).Name);                   
            //    }
            //}

            //Color white = _bitmap.GetPixel(50, 170);
            //Color black = _bitmap.GetPixel(52, 329);
        }

        private void PictureBox1_MouseMove(object sender, MouseEventArgs e)
        {
            lblPos.Text = String.Format("X: {0}; Y: {1}", e.X, e.Y);
            if(_bitmap !=null && e.X < _bitmap.Width && e.Y <_bitmap.Height )
            {
                _lastXMouseMove = e.X;
                _lastYMouseMove = e.Y;
                Color color = _bitmap.GetPixel(e.X, e.Y);
                lblColor.Text = color.Name.Remove(0, 2).ToUpper();
                DrawRectangle(e.X + 5, e.Y, _width, _height);

                lblPercent.Text = ImageProcessor.GetDarkBackgroundPercent(e.X, e.Y, _width, _height, _bitmap.Width, _bitmap.Height ).ToString("P", CultureInfo.InvariantCulture);
            }          
        }

        private void DrawRectangle(int x, int y, int width, int height)
        {
            //redraw clear bitmap without rectangle, only image
            _bitmap = new Bitmap(_bitmapFile);
            pictureBox1.Image = _bitmap;
          
            using (Graphics g = Graphics.FromImage(_bitmap))
            {
                //g.Clear(Color.White);
                g.DrawRectangle(new Pen(Color.Red), x, y, width, height);
            }

            pictureBox1.Image = _bitmap;
        }
        
        private void button4_Click(object sender, EventArgs e)
        {
            //STAGE 1
            listBox1.Items.Clear();
            List<string> windowPercent = new List<string>();

            for (int y = 0; y <= _bitmap.Height; y += _yDensity) 
            {
                //lblColumn.Text = $"{v + 1}";

                for (int x = 0; x <= _bitmap.Width; x += _xDensity)
                {
                    //lblRow.Text = $"{h + 1}";

                    var percent = ImageProcessor.GetDarkBackgroundPercent(x, y, _width, _height, _bitmap.Width, _bitmap.Height);
                    //percents.Add($"{v}:{h}", percent);

                    //lblPercent.Text = percent.ToString("P", CultureInfo.InvariantCulture);
                    //listBox1.Items.Add($"{v}:{h}_{percent.ToString("P", CultureInfo.InvariantCulture)}");
                    windowPercent.Add($"{x}:{y}_{percent.ToString()}");
                    //listBox1.Items.Add($"{x}:{y}_{percent.ToString()}");

                    //DrawRectangle(h * horizontalDensity, v * verticalIterations, _width, _height);
                    //Application.DoEvents();
                    // Thread.Sleep(10);
                }
            }

            MessageBox.Show("STAGE 1: SCANNING DONE");
            //listBox1.Items.AddRange(windowPercent);

            //STAGE 2
            foreach (var item in windowPercent)
            {
                var xy = item.Split("_".ToCharArray())[0];
                var xyArray = xy.Split(":".ToCharArray());
                int x = int.Parse(xyArray[0]);
                int y = int.Parse(xyArray[1]);

                var percent = item.Split("_".ToCharArray())[1];
                if(double.Parse(percent) > 0.19)
                {
                    ImageProcessor.Notes.Add(new Note(x, y));
                    using (Graphics g = Graphics.FromImage(_bitmap))
                    {
                        //g.Clear(Color.White);
                        g.DrawRectangle(new Pen(Color.Red), x, y, _width, _height);
                    }                  
                }                   
            }

            pictureBox1.Image = _bitmap;
            MessageBox.Show("STAGE 2: NOTE BLOB DETECTION DONE");

            //STAGE 3
            //initialise bitmap to remove the red rectangles
            _bitmap = new Bitmap(_bitmapFile);
            pictureBox1.Image = _bitmap;

            ImageProcessor.DetectLines(_bitmap);
            ImageProcessor.GroupedNotes.Clear();
            foreach (var note in ImageProcessor.Notes)
            {
                var groupedNotes = ImageProcessor.FindGroupedNotes(note, _radius);
                ImageProcessor.DrawGroupedNotes(_bitmap, groupedNotes, _radius);
            }

            pictureBox1.Image = _bitmap;
            MessageBox.Show("STAGE 3: WHOLE NOTE DETECTION DONE");

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            //string item = listBox1.Items[listBox1.SelectedIndex].ToString();
            //var xy = item.Split("_".ToCharArray())[0];

            //int x = int.Parse(xy.Split(":".ToCharArray())[0]);
            //int y = int.Parse(xy.Split(":".ToCharArray())[1]);

            //pictureBox1.Image = _bitmap;
            //DrawRectangle(x, y, _width, _height);

            if (listBox1.SelectedIndex > ImageProcessor.OrderedGroupedNotes.Count - 1) return;

            var note = ImageProcessor.OrderedGroupedNotes[listBox1.SelectedIndex];

            //magnify note
            int magnifyCoef = 5;
            string[,]  matrix = ImageProcessor.GetPixelMatrix(note.X, note.Y, note.Width, note.Height, _bitmap);
            int width = matrix.GetLength(0);
            int height = matrix.GetLength(1);

            pbNote.Width = width * magnifyCoef;
            pbNote.Height = height * magnifyCoef;
            Bitmap bitmap = new Bitmap(pbNote.Width, pbNote.Height);

            int mx = -1, my;
            for (int x = 0; x < width * magnifyCoef; x+= magnifyCoef)
            {
                mx += 1;
                my = -1;
                for (int y = 0; y < height * magnifyCoef; y+= magnifyCoef) 
                {
                    my += 1;
                    for (int magX = 0; magX < magnifyCoef; magX++)
                    {
                        for (int magY = 0; magY < magnifyCoef; magY++)
                        {
                            bitmap.SetPixel(x + magX, y + magY, ColorTranslator.FromHtml($"#{matrix[mx, my].Remove(0, 2)}"));
                        }
                    }
                }               
            }

            pbNote.Image = bitmap;

            //draw red rectangle        
            DrawRectangle(note.X, note.Y, note.Width, note.Height);

        }

        private void button5_Click(object sender, EventArgs e)
        {
            ImageProcessor.DetectLines(_bitmap);
            listBox1.Items.Clear();

            foreach (var lineY in ImageProcessor.StaffLines)
            {
                listBox1.Items.Add(lineY);
                using (Graphics g = Graphics.FromImage(_bitmap))
                {
                    g.DrawLine(new Pen(Color.Red), 0, (float)lineY, _bitmap.Width, (float)lineY);
                }
            }

            pictureBox1.Image = _bitmap;
        }

        private void button6_Click(object sender, EventArgs e)
        {
            string detectColor = txtDetectColor.Text;

            ImageProcessor.HighlightColor(_bitmap, detectColor);
            pictureBox1.Image = _bitmap;

        }

        private void button7_Click(object sender, EventArgs e)
        {
            //https://stackoverflow.com/questions/8109218/playing-piano-tones-using-c-sharp
            //https://github.com/obiwanjacobi/midi.net
            //http://www.inspiredacoustics.com/en/MIDI_note_numbers_and_center_frequencies

            //using (MidiOut midiOut = new MidiOut(0))
            //{
            //    midiOut.Volume = 65535;
            //    midiOut.Send(MidiMessage.StartNote(60, 127, 1).RawData);
            //    //MessageBox.Show("Sent");
            //    Thread.Sleep(1000);
            //    midiOut.Send(MidiMessage.StopNote(60, 0, 1).RawData);
            //    Thread.Sleep(1000);
            //}
            //return;

            //27, 35, 42, 50, 57, 114 staff lines Y coordinates

            //detect note names, i.e. C1, A1, E2, F2..
            listBox1.Items.Clear();

            //calculate the y coordinate of the middle of each note rectangle
            foreach (var note in ImageProcessor.GroupedNotes)
            {
                var segmentStaffLines = ImageProcessor.StaffLines.GetRange(note.Segment * 5, 5);
                var midY = note.Y + ((double)note.Height / 2);

                //check if note is in the segment, on the line or just around the line
                var staffLineIndex = segmentStaffLines.FindIndex(y => y == midY || Math.Abs(y - midY) <= 1);
                if (staffLineIndex != -1)
                {
                    note.Name = NoteLevelsLookup.GetNoteNameOnStaffLine(staffLineIndex);
                }
                else
                {
                    var aboveSegment = segmentStaffLines.Where(y => y <= midY);
                    var upperBoundaryY = aboveSegment.Count() > 0 ? aboveSegment.Max() : 0;
                    var lowerBoundaryY = segmentStaffLines.Where(y => y >= midY).FirstOrDefault();

                    if (upperBoundaryY == 0 && lowerBoundaryY != 0)
                    {
                        //note is above the segment
                        note.Name = NoteLevelsLookup.GetNoteNameAboveLineAt(0);
                    }
                    else if (upperBoundaryY != 0 && lowerBoundaryY == 0)
                    {
                        //note is below the segment
                        note.Name = NoteLevelsLookup.GetNoteNameBelowLineAt(0);
                    }
                    else
                    {
                        //note is in the segment between staff lines
                        note.Name = NoteLevelsLookup.GetNoteNameBetweenStaffLines(
                            segmentStaffLines.IndexOf(upperBoundaryY),
                            segmentStaffLines.IndexOf(lowerBoundaryY));
                    }
                }

                //pnlNotes.Controls.Add(new Button() { Text = note.Name });
            }

            for (int s = 0; s < 4; s++)
            {
                //object[] noteNames = ImageProcessor.GroupedNotes.Where(n => n.Segment == s).OrderBy(o => o.X).Select(i => i.Name).ToList<object>().ToArray();
                List<GroupedNote> notes = ImageProcessor.GroupedNotes.Where(n => n.Segment == s).OrderBy(o => o.X).ToList();
                ImageProcessor.OrderedGroupedNotes.AddRange(notes);
                foreach (var note in notes)
                {
                    listBox1.Items.Add(note.Name);
                }

                //listBox1.Items.AddRange(noteNames);
                //listBox1.Items.Add(" - ");
            }

           

            //pnlNotes.Refresh();
        }
    }
}
